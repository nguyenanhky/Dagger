package gst.trainingcourse.schoolmanagement.view.fragment


import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import dagger.hilt.android.AndroidEntryPoint

import gst.trainingcourse.schoolmanagement.base.BaseDialogFragment
import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.databinding.FragmentUpdateSchoolBinding
import gst.trainingcourse.schoolmanagement.view.SchoolListViewModel

@AndroidEntryPoint
class UpdateSchoolFragment(private val viewModel :SchoolListViewModel ,private val school: School)
    : BaseDialogFragment<FragmentUpdateSchoolBinding>() {


    override fun getViewBinding(): FragmentUpdateSchoolBinding = FragmentUpdateSchoolBinding.inflate(layoutInflater)


    override fun initAction() {
        binding.updateSchool.setOnClickListener {
            viewModel.updateSchool(
                School(
                    school.schoolID,binding.updateSchoolName.text.toString(),binding.updateSchoolAddress.text.toString()
                )
            )
        dismiss()
        }
    }


    companion object{
        const val  TAG ="UpdateSchool"
    }
}