package gst.trainingcourse.schoolmanagement.di.usecase

import gst.trainingcourse.schoolmanagement.database.model.Student
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import javax.inject.Inject

class UpdateStudentUseCase @Inject constructor(
    private val schoolRepository: ISchoolRepository
){
    suspend fun updateStudent(student: Student){
        return schoolRepository.updateStudent(student)
    }
}