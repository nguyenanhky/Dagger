package gst.trainingcourse.schoolmanagement.di.usecase

import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import gst.trainingcourse.schoolmanagement.repository.SchoolRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetAllSchoolUseCase @Inject constructor(
    private val schoolRepository: ISchoolRepository
) {
    fun getAllUseCase() : Flow<List<School>> =schoolRepository.getAllSchool()
}