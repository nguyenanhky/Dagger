package gst.trainingcourse.schoolmanagement.di.usecase

import gst.trainingcourse.schoolmanagement.database.model.Student
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import javax.inject.Inject

class DeleteStudentUseCase @Inject constructor(
    private val schoolRepository: ISchoolRepository
){
    suspend fun deleteStudent(student: Student){
        return schoolRepository.deleteStudent(student)
    }
}