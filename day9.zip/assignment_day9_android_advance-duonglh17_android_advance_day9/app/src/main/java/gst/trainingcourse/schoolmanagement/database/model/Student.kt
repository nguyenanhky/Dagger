package gst.trainingcourse.schoolmanagement.database.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Student (
    val studentID :Long = 0,
    val studentName :String ,
    val studentGrade :Int,
    val schoolID :Long =0
        ) :Parcelable
