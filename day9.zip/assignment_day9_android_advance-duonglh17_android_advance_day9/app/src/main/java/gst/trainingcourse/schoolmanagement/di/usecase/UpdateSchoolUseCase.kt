package gst.trainingcourse.schoolmanagement.di.usecase

import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.database.model.Student
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import javax.inject.Inject

class UpdateSchoolUseCase @Inject constructor(
    private val schoolRepository: ISchoolRepository
){
    suspend fun updateSchool(school: School){
        return schoolRepository.updateSchool(school)
    }
}