package gst.trainingcourse.schoolmanagement.di

import android.app.Application
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import gst.trainingcourse.schoolmanagement.database.SchoolDatabase
import gst.trainingcourse.schoolmanagement.database.dao.SchoolDAO
import gst.trainingcourse.schoolmanagement.database.dao.StudentDAO
import gst.trainingcourse.schoolmanagement.utils.DispatcherProvider
import gst.trainingcourse.schoolmanagement.utils.StandardDispatcher
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class DataModule {
    @Provides
    fun provideSchoolDAO(schoolDatabase: SchoolDatabase) :SchoolDAO{
        return schoolDatabase.schoolDAO()
    }

    @Provides
    fun provideStudentDAO(schoolDatabase: SchoolDatabase) :StudentDAO{
        return schoolDatabase.studentDAO()
    }

    @Provides
    @Singleton
    fun provideSchoolDatabase(application: Application):SchoolDatabase= SchoolDatabase.getInstance(application)

    @Singleton
    @Provides
    fun providerDispatcherProviders():DispatcherProvider =StandardDispatcher()
}