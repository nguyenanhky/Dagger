package gst.trainingcourse.schoolmanagement.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import gst.trainingcourse.schoolmanagement.utils.Constant

@Entity(tableName = Constant.SCHOOL_TABLE)
data class EntitySchool (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = Constant.SCHOOL_ID)
    val schoolID :Long ,
    @ColumnInfo(name =Constant.SCHOOL_NAME)
    val schoolName :String ,
    @ColumnInfo(name =Constant.SCHOOL_ADRESS)
    val schoolAddress :String
        )