package gst.trainingcourse.schoolmanagement.view.adapter

import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.database.model.Student

interface ClickItemListener {

    fun onClickDeleteSchool(school: School)

    fun onClickDeleteStudent(student:Student)

    fun onClickUpdateSchool(school: School)

    fun onClickUpdateStudent(student: Student)
}