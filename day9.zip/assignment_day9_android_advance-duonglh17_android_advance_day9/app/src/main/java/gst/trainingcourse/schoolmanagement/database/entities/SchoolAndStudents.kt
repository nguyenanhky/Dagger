package gst.trainingcourse.schoolmanagement.database.entities

import androidx.room.Embedded
import androidx.room.Relation
import gst.trainingcourse.schoolmanagement.utils.Constant

data class SchoolAndStudents (
    @Embedded val entitySchool :EntitySchool,
    @Relation(
        parentColumn = Constant.SCHOOL_ID,
        entityColumn = Constant.SCHOOL_ID
    )
    val students :List<EntityStudent>
    )