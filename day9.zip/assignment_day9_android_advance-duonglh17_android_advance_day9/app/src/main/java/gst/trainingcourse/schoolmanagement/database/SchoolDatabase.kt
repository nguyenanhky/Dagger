package gst.trainingcourse.schoolmanagement.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import gst.trainingcourse.schoolmanagement.database.dao.SchoolDAO
import gst.trainingcourse.schoolmanagement.database.dao.StudentDAO
import gst.trainingcourse.schoolmanagement.database.entities.EntitySchool
import gst.trainingcourse.schoolmanagement.database.entities.EntityStudent
import gst.trainingcourse.schoolmanagement.utils.Constant

@Database(entities = [EntitySchool::class , EntityStudent::class],version = 1,exportSchema = false)
abstract  class SchoolDatabase :RoomDatabase() {
    abstract fun schoolDAO() :SchoolDAO
    abstract fun studentDAO() :StudentDAO

    companion object{
        private var INSTANCE :SchoolDatabase ?= null

        fun getInstance(context: Context) :SchoolDatabase = INSTANCE ?: synchronized(this){
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext ,
                SchoolDatabase::class.java ,
                Constant.DATABASE_NAME).build()
                .also {
                    INSTANCE = it
                }
        }
    }
}