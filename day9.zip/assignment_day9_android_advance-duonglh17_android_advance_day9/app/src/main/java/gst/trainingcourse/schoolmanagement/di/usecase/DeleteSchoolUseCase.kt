package gst.trainingcourse.schoolmanagement.di.usecase

import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.database.model.Student
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import javax.inject.Inject

class DeleteSchoolUseCase @Inject constructor(
    private val schoolRepository: ISchoolRepository
){
    suspend fun deletSchool(school: School){
        return schoolRepository.deleteSchool(school)
    }
}