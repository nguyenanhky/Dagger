package gst.trainingcourse.schoolmanagement.utils

object Constant {
    const val ERROR ="Error Occurred !"
    const val STUDENT_ID = "student_id"
    const val STUDENT_GRADE ="student_grade"
    const val STUDENT_NAME ="student_name"

    const val SCHOOL_NAME = "school_name"
    const val SCHOOL_ADRESS="school_address"
    const val SCHOOL_ID ="school_id"
    const val DATABASE_NAME ="SCHOOL_DATABASE"
    const val SCHOOL_TABLE="school_table"
    const val STUDENT_TABLE="student_table"
}