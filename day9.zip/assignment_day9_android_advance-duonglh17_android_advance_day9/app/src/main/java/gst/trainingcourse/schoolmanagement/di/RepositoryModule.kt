package gst.trainingcourse.schoolmanagement.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import gst.trainingcourse.schoolmanagement.database.dao.SchoolDAO
import gst.trainingcourse.schoolmanagement.database.dao.StudentDAO
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import gst.trainingcourse.schoolmanagement.repository.SchoolRepository
import gst.trainingcourse.schoolmanagement.utils.DispatcherProvider
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class RepositoryModule {

    @Singleton
    @Provides
    fun provideSchoolRepository(studentDAO: StudentDAO,schoolDAO: SchoolDAO,dispatcherProvider: DispatcherProvider):ISchoolRepository{
        return SchoolRepository(studentDAO,schoolDAO, dispatcherProvider)
    }
}