package gst.trainingcourse.schoolmanagement.repository

import gst.trainingcourse.schoolmanagement.base.Result
import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.database.model.Student
import kotlinx.coroutines.flow.Flow

interface ISchoolRepository {
    fun getAllSchool() : Flow<List<School>>

    suspend fun addSchool(school: School)

    suspend fun deleteSchool(school:School)
    suspend fun addStudent(student: Student)

    suspend fun deleteStudent(student: Student)

    suspend fun updateSchool(school: School)

    suspend fun updateStudent(student: Student)

}