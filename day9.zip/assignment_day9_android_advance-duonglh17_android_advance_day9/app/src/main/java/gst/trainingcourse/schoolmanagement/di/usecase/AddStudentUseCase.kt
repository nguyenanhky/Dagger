package gst.trainingcourse.schoolmanagement.di.usecase

import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.database.model.Student
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import javax.inject.Inject

class AddStudentUseCase @Inject constructor(
    private val schoolRepository: ISchoolRepository
) {
    suspend fun addStudent(student: Student){
        return schoolRepository.addStudent(student)
    }
}