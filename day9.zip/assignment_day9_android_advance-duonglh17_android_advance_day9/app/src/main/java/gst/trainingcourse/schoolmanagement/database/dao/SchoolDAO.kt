package gst.trainingcourse.schoolmanagement.database.dao

import androidx.room.*
import gst.trainingcourse.schoolmanagement.database.entities.EntitySchool
import gst.trainingcourse.schoolmanagement.database.entities.SchoolAndStudents
import gst.trainingcourse.schoolmanagement.utils.Constant
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDAO {
    @Insert
    suspend fun insertSchool(entitySchool: EntitySchool)

    @Delete
    suspend fun deleteSchool(entitySchool:EntitySchool)

    @Update
    suspend fun updateSchool(entitySchool :EntitySchool)

    @Transaction
    @Query("select * from ${Constant.SCHOOL_TABLE}")
    fun getSchoolAndStudents() : Flow<List<SchoolAndStudents>>
}