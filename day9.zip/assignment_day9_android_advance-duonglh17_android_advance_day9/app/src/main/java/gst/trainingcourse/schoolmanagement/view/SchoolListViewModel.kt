package gst.trainingcourse.schoolmanagement.view

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import gst.trainingcourse.schoolmanagement.base.BaseViewModel
import gst.trainingcourse.schoolmanagement.base.SchoolViewState
import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.database.model.Student
import gst.trainingcourse.schoolmanagement.di.usecase.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SchoolListViewModel @Inject constructor(
    private val getAllSchoolUseCase: GetAllSchoolUseCase,
    private val addSchoolUseCase: AddSchoolUseCase,
    private val addStudentUseCase: AddStudentUseCase,
    private val deleteSchoolUseCase: DeleteSchoolUseCase,
    private val deleteStudentUseCase: DeleteStudentUseCase,
    private val updateSchoolUseCase: UpdateSchoolUseCase,
    private val updateStudentUseCase: UpdateStudentUseCase
) :BaseViewModel<SchoolViewState>(){


    private val _schoolList =MutableLiveData<List<School>>()
    val schoolList  : LiveData<List<School>>
    get() = _schoolList

    fun getSchoolList(){
        viewModelScope.launch {
            getAllSchoolUseCase.getAllUseCase().catch {
                ex->
                _viewState.value =SchoolViewState.FailOperator(ex.localizedMessage ?: "")
            }.collect {
                value ->
                _viewState.value=SchoolViewState.GetSchoolSuccess(value)
                _schoolList.value =value
            }
        }
    }

    fun addNewStudent(student: Student){
        viewModelScope.launch {
            addStudentUseCase.addStudent(student)
        }
    }

    fun addNewSchool(school :School){
        viewModelScope.launch {
            addSchoolUseCase.addSchool(school)
        }
    }

    fun deleteSchool(school: School){
        viewModelScope.launch {
            deleteSchoolUseCase.deletSchool(school)
        }
    }

    fun deleteStudent(student: Student){
        viewModelScope.launch {
            deleteStudentUseCase.deleteStudent(student)
        }
    }

    fun updateSchool(school: School){
        viewModelScope.launch {
            updateSchoolUseCase.updateSchool(school)
        }
    }

    fun updateStudent(student: Student){
        viewModelScope.launch {
            updateStudentUseCase.updateStudent(student)
        }
    }


}