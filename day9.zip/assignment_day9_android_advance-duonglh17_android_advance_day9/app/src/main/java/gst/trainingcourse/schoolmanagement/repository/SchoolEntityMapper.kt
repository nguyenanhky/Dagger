package gst.trainingcourse.schoolmanagement.repository

import gst.trainingcourse.schoolmanagement.database.entities.EntitySchool
import gst.trainingcourse.schoolmanagement.database.entities.SchoolAndStudents
import gst.trainingcourse.schoolmanagement.database.entities.EntityStudent
import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.database.model.Student

fun SchoolAndStudents.toSchool(): School {
    return this.run {
        School(
            entitySchool.schoolID,
            entitySchool.schoolName,
            entitySchool.schoolAddress,
            students.toStudents()
        )
    }
}

fun List<EntityStudent>.toStudents() :List<Student>{
    return this.map{
        studentEntity-> Student(
            studentEntity.studentID ,
            studentEntity.studentName ,
            studentEntity.studentGrade,
             studentEntity.schoolID
        )
    }
}

fun School.toSchoolEntity() :EntitySchool{
    return this.run {
        EntitySchool(schoolID,schoolName,schoolAddress)
    }
}

fun Student.toStudentEntity() :EntityStudent{
    return this.run {
        EntityStudent(studentID,studentName,studentGrade,schoolID)
    }
}