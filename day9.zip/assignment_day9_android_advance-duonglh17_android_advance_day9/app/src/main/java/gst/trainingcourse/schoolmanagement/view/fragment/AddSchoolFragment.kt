package gst.trainingcourse.schoolmanagement.view.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import dagger.hilt.android.AndroidEntryPoint
import gst.trainingcourse.schoolmanagement.R
import gst.trainingcourse.schoolmanagement.base.BaseDialogFragment
import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.databinding.FragmentAddSchoolBinding
import gst.trainingcourse.schoolmanagement.view.SchoolListViewModel

@AndroidEntryPoint
class AddSchoolFragment: BaseDialogFragment<FragmentAddSchoolBinding>(){
    private val viewModel :SchoolListViewModel by activityViewModels()


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initAction()
    }

    override fun initAction() {
        binding.addSchool.setOnClickListener {


            val schoolName :String = (binding.inputSchooName.text ).toString()
            val schoolAddress :String =(binding.inputSchoolAddress.text ).toString()

            if(schoolName.isNullOrEmpty() || schoolAddress.isNullOrEmpty() ){
                Toast.makeText(requireContext(),"Please enter school name and school address again!",Toast.LENGTH_SHORT).show()
            }
            else{
                viewModel.addNewSchool(getInputSchool(schoolName,schoolAddress))
            }

            val action = AddSchoolFragmentDirections.fromAddSchoolToList()
            findNavController().navigate(action)
        }
    }

    private fun getInputSchool(schoolName :String ,schoolAddress:String) : School {

        return School(
            schoolName = schoolName ,
            schoolAddress = schoolAddress
        )
    }



    override fun getViewBinding(): FragmentAddSchoolBinding =
        FragmentAddSchoolBinding.inflate(layoutInflater)

    companion object{
        const val  TAG ="AddSchool"
    }



}