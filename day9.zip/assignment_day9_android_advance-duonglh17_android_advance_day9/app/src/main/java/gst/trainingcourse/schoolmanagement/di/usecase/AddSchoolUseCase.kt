package gst.trainingcourse.schoolmanagement.di.usecase

import gst.trainingcourse.schoolmanagement.database.model.School
import gst.trainingcourse.schoolmanagement.repository.ISchoolRepository
import javax.inject.Inject

class AddSchoolUseCase @Inject constructor(
    private val schoolRepository: ISchoolRepository
) {

   suspend fun addSchool(school:School){
       return schoolRepository.addSchool(school)
   }
}