package gst.trainingcourse.day10_nguyenquockhanh

import android.widget.EditText
import androidx.databinding.BindingAdapter
import androidx.databinding.InverseBindingAdapter

@BindingAdapter("android:text")
fun EditText.bindObjectInText(value: Any?) {
    value?.let {
        setText(value.toString())
    }
}

@InverseBindingAdapter(attribute = "android:text")
fun EditText.getIntFromBinding(): Int = text.toString().toInt()