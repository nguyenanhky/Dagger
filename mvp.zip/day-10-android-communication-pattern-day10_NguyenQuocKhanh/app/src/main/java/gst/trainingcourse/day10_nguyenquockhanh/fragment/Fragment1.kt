package gst.trainingcourse.day10_nguyenquockhanh.fragment

import gst.trainingcourse.day10_nguyenquockhanh.isEven

class Fragment1 : BaseFragment() {
    override fun observerNumber() {
        viewModel.runningNumber.observe(viewLifecycleOwner) { number ->
            if (!number.isEven()) {
                binding.textNumber.text = number.toString()
                setBackgroundOdd()
            }
        }
    }
}