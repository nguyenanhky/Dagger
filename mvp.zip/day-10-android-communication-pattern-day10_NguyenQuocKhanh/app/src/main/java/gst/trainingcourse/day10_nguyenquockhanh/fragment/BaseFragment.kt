package gst.trainingcourse.day10_nguyenquockhanh.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import gst.trainingcourse.day10_nguyenquockhanh.NumberViewModel
import gst.trainingcourse.day10_nguyenquockhanh.R
import gst.trainingcourse.day10_nguyenquockhanh.databinding.FragmentNumberBinding

abstract class BaseFragment : Fragment() {
    private var _binding: FragmentNumberBinding? = null
    protected val binding: FragmentNumberBinding get() = _binding!!
    protected val viewModel by activityViewModels<NumberViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNumberBinding.inflate(inflater, container, false)
        setDefault()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observerPlay()
    }

    protected fun setBackgroundOdd() {
        binding.root.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.odd))
    }

    protected fun setBackgroundEven() {
        binding.root.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.even))
    }

    private fun setDefault() {
        binding.root.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.white))
        binding.textNumber.text = ""
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun observerPlay() {
        viewModel.isPlay.observe(viewLifecycleOwner) {
            if (it) {
                observerNumber()
            } else {
                setDefault()
            }
        }
    }

    abstract fun observerNumber()
}