package gst.trainingcourse.day10_nguyenquockhanh

fun Int.isEven(): Boolean = (this % 2 == 0)