package gst.trainingcourse.day10_nguyenquockhanh.fragment

import gst.trainingcourse.day10_nguyenquockhanh.isEven

class Fragment3 : BaseFragment() {
    override fun observerNumber() {
        viewModel.runningNumber.observe(viewLifecycleOwner) { number ->
            if (number % 3 == 0) {
                binding.textNumber.text = number.toString()
                if (number.isEven()) {
                    setBackgroundEven()
                } else {
                    setBackgroundOdd()
                }
            }
        }
    }
}