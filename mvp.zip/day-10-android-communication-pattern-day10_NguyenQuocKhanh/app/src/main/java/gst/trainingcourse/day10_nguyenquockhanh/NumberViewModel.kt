package gst.trainingcourse.day10_nguyenquockhanh

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NumberViewModel : ViewModel() {
    val number = MutableLiveData(0)
    val runningNumber = MutableLiveData(0)

    private val _isPlay = MutableLiveData(false)
    val isPlay: LiveData<Boolean> get() = _isPlay

    fun increaseNumber() {
        val playing = isPlay.value!!
        number.value = number.value?.plus(1)
        stop()
        if (playing) {
            play()
        } else {
            stop()
        }
    }

    fun decreaseNumber() {
        val playing = isPlay.value!!
        if (number.value != null) {
            if (number.value!! > 0) {
                number.value = number.value?.minus(1)
                stop()
            }
        }
        if (playing) {
            play()
        } else {
            stop()
        }
    }

    fun handlePlayButton() {
        if (!isPlay.value!!) {
            play()
        } else {
            stop()
        }
    }

    private fun play() {
        _isPlay.value = true
        viewModelScope.launch(Dispatchers.IO) {
            while (runningNumber.value!! < number.value!! && isPlay.value!!) {
                withContext(Dispatchers.Main) {
                    runningNumber.value = runningNumber.value!!.plus(1)
                }
                delay(1000)
            }
            withContext(Dispatchers.Main) {
                stop()
            }
        }
    }

    private fun stop() {
        runningNumber.value = 0
        _isPlay.value = false
    }
}